<?php
use \Sonata\Model;

class Account_model extends Model{
	private $table = "account";
}