<div class="row">
	<?php for($i=1;$i<=12;$i++){ ?>
	<div class="col-xl-4 col-sm-12 col-md-6">
		<div class="card mb-3">
		  <div class="row no-gutters">
		    <div class="col-sm-6">
		      <div  style="height: 100%; border-radius:0; background-image: url(https://www.dhresource.com/f2/albu/g9/M00/67/DD/rBVaWF1D1-GAe4M3AAGbfutg5TI067.jpg); background-size: contain; background-repeat: no-repeat; background-position: center;  " class="card-img border-right" alt="..."></div>
		    </div>
		    <div class="col-sm-6 bg-light">
		      <div class="card-body">
		        <h5 class="card-title">Add On</h5>
		        
		        <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
		        <p class="card-text">$ Free <a class="btn btn-outline-primary btn-sm float-right">Install</a></p>
		      </div>
		    </div>
		  </div>
		</div>
	</div>
	<?php } ?>
</div>