<div class="hbox">
	<h3>Video</h3>
</div>

<div class="hbox">
	<h3>New Video</h3>
</div>