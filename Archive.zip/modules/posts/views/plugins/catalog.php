<div class="card">
	<?php echo $data;?>
</div>
