<div class="container">
<?php echo $data->content;?>
</div>