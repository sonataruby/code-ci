<footer class="app-footer">
	<div class="container">
		<div class="row">
			<div class="col-lg-6 col-sm-12">
				<h3>Company Co.,Ltd</h3>
			</div>
			<div class="col-lg-3 col-sm-12">
				<h3>Company Info</h3>
			</div>
			<div class="col-lg-3 col-sm-12">
				<h3>Social</h3>
			</div>
		</div>
	</div>
</footer>