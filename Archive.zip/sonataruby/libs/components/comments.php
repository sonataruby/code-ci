<form>
  <div class="form-row mb-3">
    <div class="col">
      <input type="text" class="form-control" placeholder="First name">
    </div>
    <div class="col">
      <input type="text" class="form-control" placeholder="Last name">
    </div>
  </div>
  <div class="form-row mb-3">
    <div class="col">
	  <textarea class="form-control"></textarea>
	</div>
  </div>
  <button class="btn btn-outline-primary">Post Comments</button>
</form>