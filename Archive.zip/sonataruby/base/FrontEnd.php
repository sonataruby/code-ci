<?php
defined('BASEPATH') OR exit('No direct script access allowed');
namespace Sonata;
use Exception;
use stdClass;
use \Sonata\Controller;

class FrontEnd extends Controller{
	function __construct()
	{
		parent::__construct();
		define("IS_FRONTEND",true);
	}
}
