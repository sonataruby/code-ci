jQuery(document).ready(function(){
	

	
	$('[data-toggle="collapse"]').collapse({
	  toggle: false
	});
});