<!doctype html>
<html class="no-js" lang="en">
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="initial-scale=1,user-scalable=no,width=device-width">
      <title><?php echo @$header["title"];?></title>  
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />    
      <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">    
      <meta name="author" content="VTNPLUS Co.,ltd 2009-<?php echo date("Y");?>">
      <meta name="copyright" content="<?php echo @get_instance()->apps->company_name;?>">
      <meta name="datetime" content="<?php echo date("r");?>">
      <meta name="token" content="<?php echo date("r");?>">
      <link rel="canonical" href="<?php echo site_url();?>"/>
      <link rel="icon" href="<?php echo @get_instance()->apps->icoin;?>" type="image/x-icon" />
      <link rel="shortcut icon" href="<?php echo @get_instance()->apps->icoin;?>" type="image/x-icon" />
      <meta name="description" content="<?php echo @$header["description"];?>">
      <meta name="keywords" content="<?php echo @$header["keyword"];?>">
      <meta name="robots" content="index,follow"/>
      <meta name="googlebot" content="index, follow"/>
      <meta name="Googlebot-News" content="index, follow"/>
      <meta name="Googlebot-Shopping" content="index, follow">
      <meta name="Feedfetcher-Google" content="index, follow">
      <meta name="Bingbot" content="index, follow">
      <meta name="msnbot" content="index, follow">    
      <meta property="og:title" content="<?php echo @$header["title"];?>"/>
      <meta property="og:description" content="<?php echo @$header["description"];?>"/>
      <meta property="og:url" content="<?php echo current_url();?>"/>
      <meta property="og:image" content="<?php echo @$header["image"];?>"/>
      <meta property="og:type" content="website"/>
      <meta property="og:site_name" content="<?php echo @$header["title"];?>"/>
      
      <?php libs_url('css/bootstrap.css',['name' => "Bootstrap CSS"]);?>
      <?php libs_url('icoins/css/icoin.css',['name' => "Font Icoin CSS"]);?>
      <?php libs_url('css/admin-theme.css',['name' => "Admin CSS"]);?>
      <?php libs_url('css/bs-theme.css',['name' => "BS CSS"]);?>
      <link rel="alternate" type="application/rss+xml" title="Sitemap Feed for <?php echo site_url();?>" href="<?php echo site_url("sitemap.xml");?>" />
      <link rel="alternate" type="application/rss+xml" title="RSS Feed for <?php echo site_url();?>" href="<?php echo site_url("feeds");?>" />
      
      <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
      <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
      <![endif]-->
      <!--script type="text/javascript">(function(w,d,u){w.readyQ=[];w.bindReadyQ=[];function p(x,y){if(x=="ready"){w.bindReadyQ.push(y);}else{w.readyQ.push(x);}};var a={ready:p,bind:p};w.$=w.jQuery=function(f){if(f===d||f===u){return a}else{p(f)}}})(window,document)</script -->
      
      <?php echo template_url("styles.css");?>
      <?php libs_url('js/app.js',['name' => "Bootstrap & Jquery"]);?>

      <script type="text/javascript">
        var base_url = '<?php echo site_url();?>';
        var base_target = 'enterprise';
      </script>
</head>


  <body class="app theme-default" itemscope itemtype="http://schema.org/WebPage">
    <div id="loader">

        <div class="load-bar">
          <div class="bar"></div>
          <div class="bar"></div>
          <div class="bar"></div>
        </div>
    </div>

    <header class="fixed-top">
      <?php getfile("header.php"); ?>
    </header>
    <aside>
      
      
      <div class="aside-content">
        

          <ul class="nav flex-column">
            <li class="nav-item">
              <a class="nav-link bannerHeader text-white" href="/home/enterprise"><i class="fab fa-accusoft fa-2x"></i> <span>Dashboard</span></a>
              
              <div id="multiCollapseExample2" class="slidebar">
                <div class="menuHeader">
                  <h3>Trang chính</h3>
                  <p>Quản lý trang</p>
                </div>
                <a class="dropdown-item" href="#"><i class="fa fa-file-word"></i> Categories</a>
                <a class="dropdown-item" href="#"><i class="fa fa-file-word"></i> Posts</a>
                <a class="dropdown-item" href="#"><i class="fa fa-file-word"></i> Something else here</a>
              </div>
            </li>
            <li class="nav-item" id="pages">
              <a class="nav-link active" href="#"><i class="fa fa-file-word"></i> <span>Pages</span></a>
              <div id="multiCollapseExample2" class="slidebar">
                <div class="menuHeader">
                  <h4>Layout <a class="btn btn-primary btn-sm float-right" href="/pages/layout/create" sn-link="true" parent-controller="#pages"><i class="fa fa-plus"></i> Add</a></h4>
                  <p>Quản lý trang giao diện</p>

                </div>
                 <?php
                  $data = get_instance()->layout_model->getList();
                  foreach ($data as $key => $value) { ?>
                    <a class="dropdown-item" href="/pages/layout/create/<?php echo $value->id;?>" sn-link="true" parent-controller="#pages"><i class="fa fa-file-word"></i> <?php echo $value->name;?></a>
                  <?php } ?>

                <div class="menuHeader">
                  <h3>Pages <a class="btn btn-primary btn-sm float-right" href="/pages/enterprise/create" sn-link="true" parent-controller="#pages"><i class="fa fa-plus"></i> Add</a></h3>
                  <p>Quản lý trang</p>

                </div>
                  <?php
                  $data = get_instance()->pages_model->getList();
                  foreach ($data as $key => $value) { ?>
                    <a class="dropdown-item" href="/pages/enterprise/create/<?php echo $value->id;?>" sn-link="true" parent-controller="#pages"><i class="<?php echo ($value->icoin ? $value->icoin : "fa fa-file-word");?>"></i> <?php echo $value->name;?></a>
                  <?php } ?>
                
                
                
              </div>
            </li>
            <li class="nav-item" id="posts">
              <a class="nav-link arrow-down" href="/posts/enterprise/create" sn-link="true" parent-controller="#posts"><i class="fa fa-mail-bulk"></i> <span>Nội dung</span></a>
              <div id="multiCollapseExample2" class="slidebar">
                <div class="menuHeader">
                  <h3>Posts <a class="btn btn-primary btn-sm float-right" href="/posts/enterprise/create" sn-link="true" parent-controller="#posts"><i class="fa fa-plus"></i> Add</a></h3>
                  <p>Menu controller posts</p>
                </div>
                <a class="dropdown-item" href="/posts/enterprise/catalog" sn-link="true" parent-controller="#posts"><i class="fa fa-table"></i> Chuyên mục</a>
                <a class="dropdown-item" href="/posts/enterprise/posts" sn-link="true" parent-controller="#posts"><i class="fa fa-clipboard"></i> Bài viết</a>
                <a class="dropdown-item" href="/posts/enterprise/tags" sn-link="true" parent-controller="#posts"><i class="fa fa-tags"></i> Tag's</a>
                <a class="dropdown-item" href="/posts/enterprise/gallery" sn-link="true" parent-controller="#posts"><i class="fa fa-image"></i> Gallery</a>
                <a class="dropdown-item" href="/posts/enterprise/video" sn-link="true" parent-controller="#posts"><i class="fa fa-video"></i> Video</a>
                <div class="menuHeader">
                  <h3>Tools</h3>
                  <p>Menu controller posts</p>
                </div>
              </div>
            </li>
            <li class="nav-item" id="templates">
              <a class="nav-link" href="#"><i class="fa fa-campground"></i> <span>Template</span></a>
              <div id="multiCollapseExample2" class="slidebar">
                <div class="menuHeader">
                  <h3>Template</h3>
                  <p>Menu controller posts</p>
                </div>
                <a class="dropdown-item" href="/settings/enterprise/template/manager" sn-link="true" parent-controller="#templates">Manager</a>
                <a class="dropdown-item" href="/settings/enterprise/template/search" sn-link="true" parent-controller="#templates">Search Templates</a>
                <a class="dropdown-item" href="/settings/enterprise/template/backups" sn-link="true" parent-controller="#templates">Backup & Upload</a>
                <a class="dropdown-item" href="/settings/enterprise/template/manager" sn-link="true" parent-controller="#templates">CSS Develop</a>
                <a class="dropdown-item" href="/settings/enterprise/template/manager" sn-link="true" parent-controller="#templates">Item Develop</a>

                <div class="menuHeader">
                  <h5>Custom Design</h5>
                </div>
                <a class="dropdown-item" href="/settings/enterprise/menu/manager" sn-link="true" parent-controller="#templates">Menu Manager</a>
                <a class="dropdown-item" href="/settings/enterprise/template/header" sn-link="true" parent-controller="#templates">Header & Footer</a>
                <a class="dropdown-item" href="/settings/enterprise/template/blocks" sn-link="true" parent-controller="#templates">Block Manager</a>

              </div>
            </li>
            <li class="nav-item" id="apps">
              <a class="nav-link" href="#"><i class="fa fa-sitemap"></i> <span>Apps</span></a>
              <div id="multiCollapseExample2" class="slidebar">
                <div class="menuHeader">
                  <h3>Apps</h3>
                  <p>Menu controller posts</p>
                </div>
                <a class="dropdown-item" href="/settings/enterprise/addon/manager" sn-link="true" parent-controller="#apps">Manager</a>
                <a class="dropdown-item" href="/settings/enterprise/addon/search" sn-link="true" parent-controller="#apps">Search Apps</a>
                <a class="dropdown-item" href="/settings/enterprise/addon/backups" sn-link="true" parent-controller="#apps">Backup & Upload</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="/settings/enterprise/addon/plugins" sn-link="true" parent-controller="#apps">Plugins</a>
              </div>
            </li>

            <li class="nav-item">
              <a class="nav-link" href="#"><i class="fa fa-poll"></i> <span>Marketings</span></a>
            </li>

            <li class="nav-item">
              <a class="nav-link" href="#"><i class="fa fa-tasks"></i> <span>Task</span></a>
            </li>

            <li class="nav-item" id="settings">
              <a class="nav-link" href="/settings/enterprise/configs" sn-link="true" parent-controller="#settings"><i class="fa fa-cogs"></i> <span>Settings</span></a>
              <div id="multiCollapseExample2" class="slidebar">
                <div class="menuHeader">
                  <h3>Settings</h3>
                  <p>Menu controller posts</p>
                  
                </div>
                <a class="dropdown-item" href="/settings/enterprise/configs/api" sn-link="true" parent-controller="#settings"><i class="fa fa-api"></i> API Manager</a>
                <a class="dropdown-item" href="/settings/enterprise/configs" sn-link="true" parent-controller="#settings"><i class="fa fa-cogs"></i> System Settings</a>
              </div>
            </li>
          </ul>
      </div>
    </aside>
    <section class="app-content">
      <div class="app-body" sn-body="content">
        <?php print_r($content);?>
      </div>
    </section>
    <?php getfile("footer.php"); ?>
  
  <?php libs_url("js/admin.js");?>
  <?php echo template_url("app.js");?>

  <!--script type="text/javascript">(function($,d){$.each(readyQ,function(i,f){$(f)});$.each(bindReadyQ,function(i,f){$(d).bind("ready",f)})})(jQuery,document)</script -->

  </body>
  </html>